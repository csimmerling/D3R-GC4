o=$(($2-1))
echo $o
~/.local/bin/parmed ${1}.prm7 <<EOF
loadRestrt ${1}.rst7
change charge :$2,$o 0.0
change charge :$2,$o@C10 0.118100
change charge :$2,$o@C11 0.067800
change charge :$2,$o@C12 -0.096000
change charge :$2,$o@C13 -0.077000
change charge :$2,$o@C14 -0.148300
change charge :$2,$o@C15 0.021900
change charge :$2,$o@C16 -0.099000
change charge :$2,$o@C17 0.115300
change charge :$2,$o@C181 0.076000
change charge :$2,$o@C18 -0.107400
change charge :$2,$o@C19 -0.074700
change charge :$2,$o@C1 0.388800
change charge :$2,$o@C20 -0.107400
change charge :$2,$o@C21 0.115300
change charge :$2,$o@C22 0.689200
change charge :$2,$o@C23 -0.104300
change charge :$2,$o@C24 0.111800
change charge :$2,$o@C25 0.117300
change charge :$2,$o@C26 -0.148400
change charge :$2,$o@C27 -0.084400
change charge :$2,$o@C28 -0.148400
change charge :$2,$o@C29 0.117300
change charge :$2,$o@C2 -0.248600
change charge :$2,$o@C3 -0.059600
change charge :$2,$o@C4 -0.048100
change charge :$2,$o@C5 -0.369300
change charge :$2,$o@C6 0.232800
change charge :$2,$o@C7 0.294100
change charge :$2,$o@C8 -0.066500
change charge :$2,$o@C9 0.025300
change charge :$2,$o@H99 0.066700
change charge :$2,$o@F1 -0.244967
change charge :$2,$o@F2 -0.244967
change charge :$2,$o@F3 -0.244967
change charge :$2,$o@H10 0.095700
change charge :$2,$o@H11 0.095700
change charge :$2,$o@H12 0.099700
change charge :$2,$o@H13 0.114700
change charge :$2,$o@H14 0.114700
change charge :$2,$o@H15 0.097700
change charge :$2,$o@H16 0.097700
change charge :$2,$o@H17 0.088950
change charge :$2,$o@H186 0.437000
change charge :$2,$o@H18 0.088950
change charge :$2,$o@C180 0.067700
change charge :$2,$o@H1 0.080200
change charge :$2,$o@H20 0.088950
change charge :$2,$o@H21 0.088950
change charge :$2,$o@H22 0.097700
change charge :$2,$o@H23 0.097700
change charge :$2,$o@H24 0.111200
change charge :$2,$o@H25 0.111200
change charge :$2,$o@H26 0.117700
change charge :$2,$o@H27 0.117700
change charge :$2,$o@H28 0.105200
change charge :$2,$o@H29 0.105200
change charge :$2,$o@H2 0.080200
change charge :$2,$o@F360 0.103450
change charge :$2,$o@F361 0.103450
change charge :$2,$o@H32 0.066700
change charge :$2,$o@H33 0.103450
change charge :$2,$o@H34 0.103450
change charge :$2,$o@H35 0.105200
change charge :$2,$o@H36 0.105200
change charge :$2,$o@H3 0.125700
change charge :$2,$o@H44 0.168000
change charge :$2,$o@H45 0.169000
change charge :$2,$o@H46 0.162000
change charge :$2,$o@H47 0.461800
change charge :$2,$o@H48 0.453800
change charge :$2,$o@H4 0.125700
change charge :$2,$o@H5 0.125700
change charge :$2,$o@H6 0.066200
change charge :$2,$o@H7 0.066200
change charge :$2,$o@H8 0.074700
change charge :$2,$o@H9 0.074700
change charge :$2,$o@N1 -0.546800
change charge :$2,$o@N2 0.077400
change charge :$2,$o@N3 -0.810500
change charge :$2,$o@N4 -0.684400
change charge :$2,$o@N5 -0.691400
change charge :$2,$o@O180 -0.594800
change charge :$2,$o@O1 -0.645300
change charge :$2,$o@O2 -0.645300
change charge :$2,$o@S1 -0.118000
change charge :$2,$o@S2 1.459900
addLJType :$2@H180,H181,H182,H183,H184,H185 radius 0 epsilon 0 radius_14 0 epsilon_14 0
addLJType :$2@C180,C181 radius 1.4593 epsilon 0.0208 radius_14 1.4593 epsilon_14 0.0208
setBond :$2@C180 :$2@C19 375.9000 1.0970
setBond :$2@C181 :$2@C19 375.9000 1.0970
setAngle :$2@C180 :$2@C19 :$2@C181 39.0000 107.5800
setAngle :$2@C180 :$2@C19 :$2@C20 46.8000 109.8000
setAngle :$2@C180 :$2@C19 :$2@C18 46.8000 109.8000
setAngle :$2@C181 :$2@C19 :$2@C20 46.8000 109.8000
setAngle :$2@C181 :$2@C19 :$2@C18 46.8000 109.8000

deleteDihedral :$2@C180 :$2@C19 :$2@C20 :$2@C21
deleteDihedral :$2@C180 :$2@C19 :$2@C20 :$2@H20
deleteDihedral :$2@C180 :$2@C19 :$2@C20 :$2@H21
deleteDihedral :$2@C180 :$2@C19 :$2@C18 :$2@C17
deleteDihedral :$2@C180 :$2@C19 :$2@C18 :$2@H17
deleteDihedral :$2@C180 :$2@C19 :$2@C18 :$2@H18
deleteDihedral :$2@C181 :$2@C19 :$2@C20 :$2@C21
deleteDihedral :$2@C181 :$2@C19 :$2@C20 :$2@H20
deleteDihedral :$2@C181 :$2@C19 :$2@C20 :$2@H21
deleteDihedral :$2@C181 :$2@C19 :$2@C18 :$2@C17
deleteDihedral :$2@C181 :$2@C19 :$2@C18 :$2@H17
deleteDihedral :$2@C181 :$2@C19 :$2@C18 :$2@H18

addDihedral :$2@C180 :$2@C19 :$2@C20 :$2@C21 0.0800 3 0.0 1.2 2.0
addDihedral :$2@C180 :$2@C19 :$2@C20 :$2@H20 0.1200 3 0.0 1.2 2.0
addDihedral :$2@C180 :$2@C19 :$2@C20 :$2@H21 0.1200 3 0.0 1.2 2.0
addDihedral :$2@C180 :$2@C19 :$2@C18 :$2@C17 0.0800 3 0.0 1.2 2.0
addDihedral :$2@C180 :$2@C19 :$2@C18 :$2@H17 0.1200 3 0.0 1.2 2.0
addDihedral :$2@C180 :$2@C19 :$2@C18 :$2@H18 0.1200 3 0.0 1.2 2.0
addDihedral :$2@C181 :$2@C19 :$2@C20 :$2@C21 0.0800 3 0.0 1.2 2.0
addDihedral :$2@C181 :$2@C19 :$2@C20 :$2@H20 0.1200 3 0.0 1.2 2.0
addDihedral :$2@C181 :$2@C19 :$2@C20 :$2@H21 0.1200 3 0.0 1.2 2.0
addDihedral :$2@C181 :$2@C19 :$2@C18 :$2@C17 0.0800 3 0.0 1.2 2.0
addDihedral :$2@C181 :$2@C19 :$2@C18 :$2@H17 0.1200 3 0.0 1.2 2.0
addDihedral :$2@C181 :$2@C19 :$2@C18 :$2@H18 0.1200 3 0.0 1.2 2.0

addLJType :$2@F360,F361 radius 1.4593 epsilon 0.0208 radius_14 1.4593 epsilon_14 0.0208
setBond :$2@F360 :$2@C26 375.9000 1.0970
setBond :$2@F361 :$2@C26 375.9000 1.0970
setAngle :$2@F360 :$2@C26 :$2@F361 39.0000 107.5800
setAngle :$2@F360 :$2@C26 :$2@C25 46.8000 109.8000
setAngle :$2@F360 :$2@C26 :$2@C27 46.8000 109.8000
setAngle :$2@F361 :$2@C26 :$2@C25 46.8000 109.8000
setAngle :$2@F361 :$2@C26 :$2@C27 46.8000 109.8000

deleteDihedral :$2@F360 :$2@C26 :$2@C27 :$2@H99
deleteDihedral :$2@F360 :$2@C26 :$2@C27 :$2@H32
deleteDihedral :$2@F360 :$2@C26 :$2@C27 :$2@C28
deleteDihedral :$2@F361 :$2@C26 :$2@C27 :$2@H99
deleteDihedral :$2@F361 :$2@C26 :$2@C27 :$2@H32
deleteDihedral :$2@F361 :$2@C26 :$2@C27 :$2@C28

addDihedral :$2@F360 :$2@C26 :$2@C27 :$2@H99 0.1200 3 0 1.2 2.0
addDihedral :$2@F360 :$2@C26 :$2@C27 :$2@H32 0.1200 3 0 1.2 2.0
addDihedral :$2@F360 :$2@C26 :$2@C27 :$2@C28 0.8000 3 0 1.2 2.0
addDihedral :$2@F361 :$2@C26 :$2@C27 :$2@H99 0.1200 3 0 1.2 2.0
addDihedral :$2@F361 :$2@C26 :$2@C27 :$2@H32 0.1200 3 0 1.2 2.0
addDihedral :$2@F361 :$2@C26 :$2@C27 :$2@C28 0.8000 3 0 1.2 2.0

setOverwrite
tiMerge :1 :2 :$o :$2
outparm ${1}_merged.prm7 ${1}_merged.rst7
quit

EOF

