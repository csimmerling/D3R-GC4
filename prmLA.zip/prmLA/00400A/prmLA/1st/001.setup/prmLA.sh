o=$(($2-222))
echo $o
~/.local/bin/parmed ${1}.prm7 <<EOF
loadRestrt ${1}.rst7
change charge :$2 0.0
change charge :$2@C10 -0.130400
change charge :$2@C11 0.097800
change charge :$2@C12 -0.083000
change charge :$2@C13 -0.079000
change charge :$2@C14 -0.140300
change charge :$2@C15 0.010900
change charge :$2@C16 -0.088000
change charge :$2@C17 0.110800
change charge :$2@C18 -0.137900
change charge :$2@C19 0.142700
change charge :$2@C1 0.373800
change charge :$2@C20 -0.137900
change charge :$2@C21 0.110800
change charge :$2@C22 0.688200
change charge :$2@C23 -0.097300
change charge :$2@C24 0.113800
change charge :$2@C25 0.116300
change charge :$2@C26 -0.110900
change charge :$2@C27 -0.237400
change charge :$2@C28 -0.110900
change charge :$2@C29 0.116300
change charge :$2@C2 -0.270600
change charge :$2@C30 0.099700
change charge :$2@C31 0.094000
change charge :$2@C32 -0.093400
change charge :$2@C33 -0.151400
change charge :$2@C34 0.708500
change charge :$2@C3 -0.103600
change charge :$2@C4 -0.045100
change charge :$2@C5 -0.367300
change charge :$2@C6 0.216800
change charge :$2@C7 0.280100
change charge :$2@C8 -0.070500
change charge :$2@C9 0.055300
change charge :$2@F1 -0.244633
change charge :$2@F2 -0.244633
change charge :$2@F3 -0.244633
change charge :$2@H10 0.094700
change charge :$2@H11 0.094700
change charge :$2@H12 0.082700
change charge :$2@H13 0.111700
change charge :$2@H14 0.111700
change charge :$2@H15 0.107450
change charge :$2@H16 0.107450
change charge :$2@H17 0.099950
change charge :$2@H18 0.099950
change charge :$2@H19 0.065700
change charge :$2@H1 0.070200
change charge :$2@H20 0.099950
change charge :$2@H21 0.099950
change charge :$2@H22 0.107450
change charge :$2@H23 0.107450
change charge :$2@H24 0.110200
change charge :$2@H25 0.110200
change charge :$2@H26 0.116700
change charge :$2@H27 0.116700
change charge :$2@H28 0.106450
change charge :$2@H29 0.106450
change charge :$2@H2 0.070200
change charge :$2@H30 0.104200
change charge :$2@H31 0.104200
change charge :$2@H32 0.099700
change charge :$2@H33 0.104200
change charge :$2@H34 0.104200
change charge :$2@H35 0.106450
change charge :$2@H36 0.106450
change charge :$2@H37 0.051700
change charge :$2@H38 0.051700
change charge :$2@H39 0.073200
change charge :$2@H3 0.136033
change charge :$2@H40 0.096700
change charge :$2@H41 0.096700
change charge :$2@H42 0.073200
change charge :$2@H43 0.082700
change charge :$2@H44 0.165000
change charge :$2@H45 0.171000
change charge :$2@H46 0.169000
change charge :$2@H47 0.451800
change charge :$2@H48 0.456800
change charge :$2@H4 0.136033
change charge :$2@H5 0.136033
change charge :$2@H6 0.072700
change charge :$2@H7 0.072700
change charge :$2@H8 0.088200
change charge :$2@H9 0.088200
change charge :$2@N1 -0.488800
change charge :$2@N2 0.108400
change charge :$2@N3 -0.786500
change charge :$2@N4 -0.680400
change charge :$2@N5 -0.691400
change charge :$2@N6 -0.505800
change charge :$2@O1 -0.678800
change charge :$2@O2 -0.678800
change charge :$2@O3 -0.644500
change charge :$2@S1 -0.140000
change charge :$2@S2 1.444900

setOverwrite
tiMerge :1-222 :223-444 :$o&!@H3,H4,H5,C5,S2,O1,O2,N3,C6,C7 :$2&!@H3,H4,H5,C5,S2,O1,O2,N3,C6,C7
outparm ${1}_merged.prm7 ${1}_merged.rst7
quit

EOF





