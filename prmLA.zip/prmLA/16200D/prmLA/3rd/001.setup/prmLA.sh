o=$(($2-1))
echo $o
~/.local/bin/parmed ${1}.prm7 <<EOF
loadRestrt ${1}.rst7
change charge :$2,$o 0.0
change charge :$2,$o@C10 0.118100
change charge :$2,$o@C11 0.067800
change charge :$2,$o@C12 -0.096000
change charge :$2,$o@C13 -0.077000
change charge :$2,$o@C14 -0.148300
change charge :$2,$o@C15 0.021900
change charge :$2,$o@C16 -0.099000
change charge :$2,$o@C17 0.115300
change charge :$2,$o@H221 0.076000
change charge :$2,$o@C18 -0.107400
change charge :$2,$o@C19 -0.074700
change charge :$2,$o@C1 0.388800
change charge :$2,$o@C20 -0.107400
change charge :$2,$o@C21 0.115300
change charge :$2,$o@C22 0.689200
change charge :$2,$o@C23 -0.104300
change charge :$2,$o@C24 0.111800
change charge :$2,$o@C25 0.117300
change charge :$2,$o@C26 -0.148400
change charge :$2,$o@C27 -0.084400
change charge :$2,$o@C28 -0.148400
change charge :$2,$o@C29 0.117300
change charge :$2,$o@C2 -0.248600
change charge :$2,$o@C3 -0.059600
change charge :$2,$o@C4 -0.048100
change charge :$2,$o@C6 0.232800
change charge :$2,$o@C7 0.294100
change charge :$2,$o@C8 -0.066500
change charge :$2,$o@C9 0.025300
change charge :$2,$o@F180 0.066700
change charge :$2,$o@F1 -0.244967
change charge :$2,$o@F2 -0.244967
change charge :$2,$o@F3 -0.244967
change charge :$2,$o@H10 0.095700
change charge :$2,$o@H11 0.095700
change charge :$2,$o@H12 0.099700
change charge :$2,$o@H13 0.114700
change charge :$2,$o@H14 0.114700
change charge :$2,$o@H15 0.097700
change charge :$2,$o@H16 0.097700
change charge :$2,$o@H17 0.088950
change charge :$2,$o@H186 0.437000
change charge :$2,$o@H18 0.088950
change charge :$2,$o@H19 0.067700
change charge :$2,$o@H1 0.080200
change charge :$2,$o@H20 0.088950
change charge :$2,$o@H21 0.088950
change charge :$2,$o@H22 0.097700
change charge :$2,$o@H23 0.097700
change charge :$2,$o@H24 0.111200
change charge :$2,$o@H25 0.111200
change charge :$2,$o@H26 0.117700
change charge :$2,$o@H27 0.117700
change charge :$2,$o@H28 0.105200
change charge :$2,$o@H29 0.105200
change charge :$2,$o@H2 0.080200
change charge :$2,$o@H30 0.103450
change charge :$2,$o@H31 0.103450
change charge :$2,$o@H32 0.066700
change charge :$2,$o@H33 0.103450
change charge :$2,$o@H34 0.103450
change charge :$2,$o@H35 0.105200
change charge :$2,$o@H36 0.105200
change charge :$2,$o@H44 0.168000
change charge :$2,$o@H45 0.169000
change charge :$2,$o@H46 0.162000
change charge :$2,$o@H47 0.461800
change charge :$2,$o@H48 0.453800
change charge :$2,$o@H6 0.066200
change charge :$2,$o@H7 0.066200
change charge :$2,$o@H8 0.074700
change charge :$2,$o@H9 0.074700
change charge :$2,$o@N1 -0.546800
change charge :$2,$o@N2 0.077400
change charge :$2,$o@N3 -0.633400
change charge :$2,$o@N4 -0.684400
change charge :$2,$o@N5 -0.691400
change charge :$2,$o@O180 -0.594800
change charge :$2,$o@S1 -0.118000
addLJType :$2,$o@O403 radius 0 epsilon 0 radius_14 0 epsilon_14 0
addLJType :$2,$o@C402,C404,H403,H404,H405,H406 radius 0 epsilon 0 radius_14 0 epsilon_14 0
addLJType :$2@C401,C405,H401,H402,H407,H408,N280,O260 radius 0 epsilon 0 radius_14 0 epsilon_14 0
addLJtype :$2@C260 radius 1.9825 epsilon 0.2824 radius_14 1.9825 epsilon_14 0.2824

addLJType :$2,$o@F180,H32 radius 1.4593 epsilon 0.0208 radius_14 1.4593 epsilon_14 0.0208
setBond :$2,$o@F180 :$2,$o@C27 375.9000 1.0970
setAngle :$2,$o@F180 :$2,$o@C27 :$2,$o@H32 39.0000 107.5800
setAngle :$2,$o@C26 :$2,$o@C27 :$2,$o@F180 46.8000 109.8000
setAngle :$2,$o@C28 :$2,$o@C27 :$2,$o@F180 46.8000 109.8000

deleteDihedral :$2,$o@H30 :$2,$o@C26 :$2,$o@C27 :$2,$o@F180
deleteDihedral :$2,$o@H31 :$2,$o@C26 :$2,$o@C27 :$2,$o@F180
deleteDihedral :$2,$o@H33 :$2,$o@C28 :$2,$o@C27 :$2,$o@F180
deleteDihedral :$2,$o@H34 :$2,$o@C28 :$2,$o@C27 :$2,$o@F180
deleteDihedral :$2,$o@C25 :$2,$o@C26 :$2,$o@C27 :$2,$o@F180
deleteDihedral :$2,$o@C29 :$2,$o@C28 :$2,$o@C27 :$2,$o@F180
deleteDihedral :$2,$o@C25 :$2,$o@C26 :$2,$o@C27 :$2,$o@H32
deleteDihedral :$2,$o@C29 :$2,$o@C28 :$2,$o@C27 :$2,$o@H32

addDihedral :$2,$o@H30 :$2,$o@C26 :$2,$o@C27 :$2,$o@F180 0.1200 3 0.0 1.2 2.0
addDihedral :$2,$o@H31 :$2,$o@C26 :$2,$o@C27 :$2,$o@F180 0.1200 3 0.0 1.2 2.0
addDihedral :$2,$o@H33 :$2,$o@C28 :$2,$o@C27 :$2,$o@F180 0.1200 3 0.0 1.2 2.0
addDihedral :$2,$o@H34 :$2,$o@C28 :$2,$o@C27 :$2,$o@F180 0.1200 3 0.0 1.2 2.0
addDihedral :$2,$o@C25 :$2,$o@C26 :$2,$o@C27 :$2,$o@F180 0.0800 3 0.0 1.2 2.0
addDihedral :$2,$o@C29 :$2,$o@C28 :$2,$o@C27 :$2,$o@F180 0.0800 3 0.0 1.2 2.0
addDihedral :$2,$o@C25 :$2,$o@C26 :$2,$o@C27 :$2,$o@H32 0.0800 3 0.0 1.2 2.0
addDihedral :$2,$o@C29 :$2,$o@C28 :$2,$o@C27 :$2,$o@H32 0.0800 3 0.0 1.2 2.0

setOverwrite
tiMerge :1 :2 :$o :$2
outparm ${1}_merged.prm7 ${1}_merged.rst7
quit

EOF

