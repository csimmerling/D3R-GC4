o=$(($2-1))
echo $o
~/.local/bin/parmed ${1}.prm7 <<EOF
loadRestrt ${1}.rst7
change charge :$2 0.0
change charge :$2@C10 -0.130400
change charge :$2@C11 0.097800
change charge :$2@C12 -0.084000
change charge :$2@C13 -0.080000
change charge :$2@C140 -0.175100
change charge :$2@C14 -0.140300
change charge :$2@C15 0.013900
change charge :$2@C16 -0.089000
change charge :$2@C17 0.110800
change charge :$2@C18 -0.137900
change charge :$2@C19 0.128700
change charge :$2@C1 0.375800
change charge :$2@C20 -0.137900
change charge :$2@C21 0.110800
change charge :$2@C22 0.688200
change charge :$2@C23 -0.095300
change charge :$2@C24 0.112800
change charge :$2@C25 0.113800
change charge :$2@C26 -0.105400
change charge :$2@C27 -0.099400
change charge :$2@C28 -0.105400
change charge :$2@C29 0.113800
change charge :$2@C2 -0.270600
change charge :$2@C34 0.672100
change charge :$2@C3 -0.104600
change charge :$2@C4 -0.045100
change charge :$2@C5 -0.367300
change charge :$2@C6 0.216800
change charge :$2@C7 0.280100
change charge :$2@C8 -0.072500
change charge :$2@C9 0.055300
change charge :$2@F1 -0.243633
change charge :$2@F2 -0.243633
change charge :$2@F3 -0.243633
change charge :$2@H10 0.094700
change charge :$2@H11 0.094700
change charge :$2@H121 0.332500
change charge :$2@H12 0.082200
change charge :$2@H13 0.112200
change charge :$2@H141 0.081367
change charge :$2@C480 0.081367
change charge :$2@O480 0.081367
change charge :$2@H14 0.112200
change charge :$2@H15 0.107700
change charge :$2@H16 0.107700
change charge :$2@H17 0.101450
change charge :$2@H18 0.101450
change charge :$2@H19 0.060700
change charge :$2@H1 0.070200
change charge :$2@H20 0.101450
change charge :$2@H21 0.101450
change charge :$2@H22 0.107700
change charge :$2@H23 0.107700
change charge :$2@H24 0.109700
change charge :$2@H25 0.109700
change charge :$2@H26 0.114700
change charge :$2@H27 0.114700
change charge :$2@H28 0.099700
change charge :$2@H29 0.099700
change charge :$2@H2 0.070200
change charge :$2@H30 0.087950
change charge :$2@H31 0.087950
change charge :$2@H32 0.078200
change charge :$2@H33 0.087950
change charge :$2@H34 0.087950
change charge :$2@H35 0.099700
change charge :$2@H36 0.099700
change charge :$2@H3 0.136033
change charge :$2@O180 0.082200
change charge :$2@H44 0.165000
change charge :$2@H45 0.171000
change charge :$2@H46 0.168000
change charge :$2@H47 0.452800
change charge :$2@H48 0.455800
change charge :$2@H4 0.136033
change charge :$2@H5 0.136033
change charge :$2@H6 0.072700
change charge :$2@H7 0.072700
change charge :$2@H8 0.088200
change charge :$2@C510 0.078200
change charge :$2@H9 0.088200
change charge :$2@N1 -0.488800
change charge :$2@N2 0.107400
change charge :$2@N3 -0.786500
change charge :$2@N4 -0.680400
change charge :$2@N5 -0.688400
change charge :$2@N6 -0.587900
change charge :$2@O1 -0.679300
change charge :$2@O2 -0.679300
change charge :$2@O3 -0.627100
change charge :$2@S1 -0.142000
change charge :$2@S2 1.444900

setOverwrite
tiMerge :1 :2 :$o :$2
outparm ${1}_merged.prm7 ${1}_merged.rst7
quit

EOF




