o=$(($2-1))
echo $o
~/.local/bin/parmed ${1}.prm7 <<EOF
loadRestrt ${1}.rst7
change charge :$2 0.0
change charge :$2@C10 0.118100
change charge :$2@C11 0.067800
change charge :$2@C12 -0.096000
change charge :$2@C13 -0.077000
change charge :$2@C14 -0.148300
change charge :$2@C15 0.021900
change charge :$2@C16 -0.099000
change charge :$2@C17 0.115300
change charge :$2@H221 0.076000
change charge :$2@C18 -0.107400
change charge :$2@C19 -0.074700
change charge :$2@C1 0.388800
change charge :$2@C20 -0.107400
change charge :$2@C21 0.115300
change charge :$2@C22 0.689200
change charge :$2@C23 -0.104300
change charge :$2@C24 0.111800
change charge :$2@C25 0.117300
change charge :$2@C26 -0.148400
change charge :$2@C27 -0.084400
change charge :$2@C28 -0.148400
change charge :$2@C29 0.117300
change charge :$2@C2 -0.248600
change charge :$2@C3 -0.059600
change charge :$2@C4 -0.048100
change charge :$2@C6 0.232800
change charge :$2@C7 0.294100
change charge :$2@C8 -0.066500
change charge :$2@C9 0.025300
change charge :$2@F180 0.066700
change charge :$2@F1 -0.244967
change charge :$2@F2 -0.244967
change charge :$2@F3 -0.244967
change charge :$2@H10 0.095700
change charge :$2@H11 0.095700
change charge :$2@H12 0.099700
change charge :$2@H13 0.114700
change charge :$2@H14 0.114700
change charge :$2@H15 0.097700
change charge :$2@H16 0.097700
change charge :$2@H17 0.088950
change charge :$2@H186 0.437000
change charge :$2@H18 0.088950
change charge :$2@H19 0.067700
change charge :$2@H1 0.080200
change charge :$2@H20 0.088950
change charge :$2@H21 0.088950
change charge :$2@H22 0.097700
change charge :$2@H23 0.097700
change charge :$2@H24 0.111200
change charge :$2@H25 0.111200
change charge :$2@H26 0.117700
change charge :$2@H27 0.117700
change charge :$2@H28 0.105200
change charge :$2@H29 0.105200
change charge :$2@H2 0.080200
change charge :$2@H30 0.103450
change charge :$2@H31 0.103450
change charge :$2@H32 0.066700
change charge :$2@H33 0.103450
change charge :$2@H34 0.103450
change charge :$2@H35 0.105200
change charge :$2@H36 0.105200
change charge :$2@H44 0.168000
change charge :$2@H45 0.169000
change charge :$2@H46 0.162000
change charge :$2@H47 0.461800
change charge :$2@H48 0.453800
change charge :$2@H6 0.066200
change charge :$2@H7 0.066200
change charge :$2@H8 0.074700
change charge :$2@H9 0.074700
change charge :$2@N1 -0.546800
change charge :$2@N2 0.077400
change charge :$2@N3 -0.633400
change charge :$2@N4 -0.684400
change charge :$2@N5 -0.691400
change charge :$2@O180 -0.594800
change charge :$2@S1 -0.118000
addLJtype :$2@C263,H263,H264,H265 radius 0 epsilon 0 radius_14 0 epsilon_14 0

setOverwrite
tiMerge :1 :2 :$o :$2
outparm ${1}_merged.prm7 ${1}_merged.rst7
quit

EOF

