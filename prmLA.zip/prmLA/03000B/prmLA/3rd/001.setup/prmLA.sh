o=$(($2-1))
echo $o
~/.local/bin/parmed ${1}.prm7 <<EOF
loadRestrt ${1}.rst7
change charge :$2,$o 0.0
change charge :$2,$o@C10 -0.130400
change charge :$2,$o@C11 0.097800
change charge :$2,$o@C12 -0.084000
change charge :$2,$o@C13 -0.080000
change charge :$2,$o@C14 -0.140300
change charge :$2,$o@C15 0.013900
change charge :$2,$o@C16 -0.089000
change charge :$2,$o@C17 0.110800
change charge :$2,$o@C18 -0.137900
change charge :$2,$o@C19 -0.073399
change charge :$2,$o@C1 0.375800
change charge :$2,$o@C20 -0.137900
change charge :$2,$o@C21 0.110800
change charge :$2,$o@C22 0.688200
change charge :$2,$o@C23 -0.095300
change charge :$2,$o@C24 0.112800
change charge :$2,$o@C25 0.113800
change charge :$2,$o@C26 -0.105400
change charge :$2,$o@C27 -0.099400
change charge :$2,$o@C28 -0.105400
change charge :$2,$o@C29 0.113800
change charge :$2,$o@C2 -0.270600
change charge :$2,$o@C3 -0.104600
change charge :$2,$o@C4 -0.045100
change charge :$2,$o@C5 -0.367300
change charge :$2,$o@C6 0.216800
change charge :$2,$o@C7 0.280100
change charge :$2,$o@C8 -0.072500
change charge :$2,$o@C9 0.055300
change charge :$2,$o@F1 -0.243633
change charge :$2,$o@F2 -0.243633
change charge :$2,$o@F3 -0.243633
change charge :$2,$o@H10 0.094700
change charge :$2,$o@H11 0.094700
change charge :$2,$o@H12 0.082200
change charge :$2,$o@H13 0.112200
change charge :$2,$o@H14 0.112200
change charge :$2,$o@H15 0.107700
change charge :$2,$o@H16 0.107700
change charge :$2,$o@H17 0.101450
change charge :$2,$o@H18 0.101450
change charge :$2,$o@H19 0.060700
change charge :$2,$o@H1 0.070200
change charge :$2,$o@H20 0.101450
change charge :$2,$o@H21 0.101450
change charge :$2,$o@H22 0.107700
change charge :$2,$o@H23 0.107700
change charge :$2,$o@H24 0.109700
change charge :$2,$o@H25 0.109700
change charge :$2,$o@H26 0.114700
change charge :$2,$o@H27 0.114700
change charge :$2,$o@H28 0.099700
change charge :$2,$o@H29 0.099700
change charge :$2,$o@H2 0.070200
change charge :$2,$o@H30 0.087950
change charge :$2,$o@H31 0.087950
change charge :$2,$o@H32 0.078200
change charge :$2,$o@H33 0.087950
change charge :$2,$o@H34 0.087950
change charge :$2,$o@H35 0.099700
change charge :$2,$o@H36 0.099700
change charge :$2,$o@H3 0.136033
change charge :$2,$o@H43 0.082200
change charge :$2,$o@H44 0.165000
change charge :$2,$o@H45 0.171000
change charge :$2,$o@H46 0.168000
change charge :$2,$o@H47 0.452800
change charge :$2,$o@H48 0.455800
change charge :$2,$o@H4 0.136033
change charge :$2,$o@H5 0.136033
change charge :$2,$o@H6 0.072700
change charge :$2,$o@H7 0.072700
change charge :$2,$o@H8 0.088200
change charge :$2,$o@H99 0.078200
change charge :$2,$o@H9 0.088200
change charge :$2,$o@N1 -0.488800
change charge :$2,$o@N2 0.107400
change charge :$2,$o@N3 -0.786500
change charge :$2,$o@N4 -0.680400
change charge :$2,$o@N5 -0.688400
change charge :$2,$o@N6 0.060700
change charge :$2,$o@O1 -0.679300
change charge :$2,$o@O2 -0.679300
change charge :$2,$o@S1 -0.142000
change charge :$2,$o@S2 1.444900
addLJType :$2,$o@H141,H142,H143 radius 0 epsilon 0 radius_14 0 epsilon_14 0
setBond :$2,$o@C140 :$2,$o@C34 372.9000 1.3580
setAngle :$2,$o@C140 :$2,$o@C34 :$2,$o@N6 75.3000 109.2200
setAngle :$2,$o@C140 :$2,$o@C34 :$2,$o@O3 114.8000 123.2501
deleteDihedral :$2,$o@C140 :$2,$o@C34 :$2,$o@N6 :$2,$o@C19
addDihedral :$2,$o@C140 :$2,$o@C34 :$2,$o@N6 :$2,$o@C19 2.5 2 180.0001 1.2 2.0

addLJType :$2,$o@C140,O3 radius 0 epsilon 0 radius_14 0 epsilon_14 0

addLJType :$2@C34,H121 radius 0 epsilon 0 radius_14 0 epsilon_14 0
addLJType :$2@N6,H19 radius 1.4593 epsilon 0.0208 radius_14 1.4593 epsilon_14 0.0208
setBond :$2@N6 :$2@C19 375.9000 1.0970
setAngle :$2@N6 :$2@C19 :$2@H19 39.0000 107.5800
setAngle :$2@N6 :$2@C19 :$2@C20 49.8000 108.8800
setAngle :$2@N6 :$2@C19 :$2@C18 49.8000 108.8800
deleteDihedral :$2@N6 :$2@C19 :$2@C20 :$2@C21
deleteDihedral :$2@N6 :$2@C19 :$2@C20 :$2@H20
deleteDihedral :$2@N6 :$2@C19 :$2@C20 :$2@H21
deleteDihedral :$2@N6 :$2@C19 :$2@C18 :$2@C17
deleteDihedral :$2@N6 :$2@C19 :$2@C18 :$2@H17
deleteDihedral :$2@N6 :$2@C19 :$2@C18 :$2@H18

addDihedral :$2@N6 :$2@C19 :$2@C20 :$2@C21 0.0800 3 0.0 1.2 2.0
addDihedral :$2@N6 :$2@C19 :$2@C20 :$2@H20 0.1200 3 0.0 1.2 2.0
addDihedral :$2@N6 :$2@C19 :$2@C20 :$2@H21 0.1200 3 0.0 1.2 2.0
addDihedral :$2@N6 :$2@C19 :$2@C18 :$2@C17 0.0800 3 0.0 1.2 2.0
addDihedral :$2@N6 :$2@C19 :$2@C18 :$2@H17 0.1200 3 0.0 1.2 2.0
addDihedral :$2@N6 :$2@C19 :$2@C18 :$2@H18 0.1200 3 0.0 1.2 2.0

deleteDihedral :$2@H19 :$2@C19 :$2@C20 :$2@C21
deleteDihedral :$2@H19 :$2@C19 :$2@C20 :$2@H20
deleteDihedral :$2@H19 :$2@C19 :$2@C20 :$2@H21
deleteDihedral :$2@H19 :$2@C19 :$2@C18 :$2@C17
deleteDihedral :$2@H19 :$2@C19 :$2@C18 :$2@H17
deleteDihedral :$2@H19 :$2@C19 :$2@C18 :$2@H18

addDihedral :$2@H19 :$2@C19 :$2@C20 :$2@C21 0.0800 3 0.0 1.2 2.0
addDihedral :$2@H19 :$2@C19 :$2@C20 :$2@H20 0.1200 3 0.0 1.2 2.0
addDihedral :$2@H19 :$2@C19 :$2@C20 :$2@H21 0.1200 3 0.0 1.2 2.0
addDihedral :$2@H19 :$2@C19 :$2@C18 :$2@C17 0.0800 3 0.0 1.2 2.0
addDihedral :$2@H19 :$2@C19 :$2@C18 :$2@H17 0.1200 3 0.0 1.2 2.0
addDihedral :$2@H19 :$2@C19 :$2@C18 :$2@H18 0.1200 3 0.0 1.2 2.0

setOverwrite
tiMerge :1 :2 :$o :$2
outparm ${1}_merged.prm7 ${1}_merged.rst7
quit

EOF





