#!/bin/bash
#SBATCH --gres=gpu:1
#SBATCH --job-name 004
#SBATCH -p 2080,1080,980,780,680
source /opt/amber/amber.sh
/opt/amber/bin/pmemd.cuda -O -i ./md8_v1_0.999 -p ../../001.setup/004_merged.prm7 -c ./md7.rst7 -o ./md8.out -x ./md8.trj -e ./md8eng -v ./md8vel -r ./md8.rst7 

