#!/bin/bash
#SBATCH --gres=gpu:1
#SBATCH --job-name 004
#SBATCH -p 2080,1080,980,780,680
source /opt/amber/amber.sh
/opt/amber/bin/pmemd.cuda -O -i ./md9_v1_0.31608 -p ../../001.setup/004_merged.prm7 -c ./md8.rst7 -o ./md9.out -x ./md9.trj -e ./md9eng -v ./md9vel -r ./md9.rst7 

