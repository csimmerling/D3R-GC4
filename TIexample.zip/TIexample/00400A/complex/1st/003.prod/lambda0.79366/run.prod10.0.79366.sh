#!/bin/bash
#SBATCH --gres=gpu:1
#SBATCH --job-name 004
#SBATCH -p 2080,1080,980,780,680
source /opt/amber/amber.sh
/opt/amber/bin/pmemd.cuda -O -i ./md10_v1_0.79366 -p ../../001.setup/004_merged.prm7 -c ./md9.rst7 -o ./md10.out -x ./md10.trj -e ./md10eng -v ./md10vel -r ./md10.rst7 

