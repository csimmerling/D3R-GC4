#!/bin/bash
#SBATCH --gres=gpu:1
#SBATCH --job-name 004
#SBATCH -p 2080,1080,980,780,680
source /opt/amber/amber.sh
/opt/amber/bin/pmemd.cuda -O -i ./md7_v1_0.995 -p ../../001.setup/004_merged.prm7 -c ./md6.rst7 -o ./md7.out -x ./md7.trj -e ./md7eng -v ./md7vel -r ./md7.rst7 

