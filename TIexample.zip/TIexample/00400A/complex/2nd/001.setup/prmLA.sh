o=$(($2-222))
echo $o
~/.local/bin/parmed ${1}.prm7 <<EOF
loadRestrt ${1}.rst7
change charge :$2,$o 0.0
change charge :$2,$o@C10 -0.130400
change charge :$2,$o@C11 0.097800
change charge :$2,$o@C12 -0.083000
change charge :$2,$o@C13 -0.079000
change charge :$2,$o@C14 -0.140300
change charge :$2,$o@C15 0.010900
change charge :$2,$o@C16 -0.088000
change charge :$2,$o@C17 0.110800
change charge :$2,$o@C18 -0.137900
change charge :$2,$o@C19 0.142700
change charge :$2,$o@C1 0.373800
change charge :$2,$o@C20 -0.137900
change charge :$2,$o@C21 0.110800
change charge :$2,$o@C22 0.688200
change charge :$2,$o@C23 -0.097300
change charge :$2,$o@C24 0.113800
change charge :$2,$o@C25 0.116300
change charge :$2,$o@C26 -0.110900
change charge :$2,$o@C27 -0.237400
change charge :$2,$o@C28 -0.110900
change charge :$2,$o@C29 0.116300
change charge :$2,$o@C2 -0.270600
change charge :$2,$o@C30 0.099700
change charge :$2,$o@C31 0.094000
change charge :$2,$o@C32 -0.093400
change charge :$2,$o@C33 -0.151400
change charge :$2,$o@C34 0.708500
change charge :$2,$o@C3 -0.103600
change charge :$2,$o@C4 -0.045100
change charge :$2,$o@C5 -0.367300
change charge :$2,$o@C6 0.216800
change charge :$2,$o@C7 0.280100
change charge :$2,$o@C8 -0.070500
change charge :$2,$o@C9 0.055300
change charge :$2,$o@F1 -0.244633
change charge :$2,$o@F2 -0.244633
change charge :$2,$o@F3 -0.244633
change charge :$2,$o@H10 0.094700
change charge :$2,$o@H11 0.094700
change charge :$2,$o@H12 0.082700
change charge :$2,$o@H13 0.111700
change charge :$2,$o@H14 0.111700
change charge :$2,$o@H15 0.107450
change charge :$2,$o@H16 0.107450
change charge :$2,$o@H17 0.099950
change charge :$2,$o@H18 0.099950
change charge :$2,$o@H19 0.065700
change charge :$2,$o@H1 0.070200
change charge :$2,$o@H20 0.099950
change charge :$2,$o@H21 0.099950
change charge :$2,$o@H22 0.107450
change charge :$2,$o@H23 0.107450
change charge :$2,$o@H24 0.110200
change charge :$2,$o@H25 0.110200
change charge :$2,$o@H26 0.116700
change charge :$2,$o@H27 0.116700
change charge :$2,$o@H28 0.106450
change charge :$2,$o@H29 0.106450
change charge :$2,$o@H2 0.070200
change charge :$2,$o@H30 0.104200
change charge :$2,$o@H31 0.104200
change charge :$2,$o@H32 0.099700
change charge :$2,$o@H33 0.104200
change charge :$2,$o@H34 0.104200
change charge :$2,$o@H35 0.106450
change charge :$2,$o@H36 0.106450
change charge :$2,$o@H37 0.051700
change charge :$2,$o@H38 0.051700
change charge :$2,$o@H39 0.073200
change charge :$2,$o@H3 0.136033
change charge :$2,$o@H40 0.096700
change charge :$2,$o@H41 0.096700
change charge :$2,$o@H42 0.073200
change charge :$2,$o@H43 0.082700
change charge :$2,$o@H44 0.165000
change charge :$2,$o@H45 0.171000
change charge :$2,$o@H46 0.169000
change charge :$2,$o@H47 0.451800
change charge :$2,$o@H48 0.456800
change charge :$2,$o@H4 0.136033
change charge :$2,$o@H5 0.136033
change charge :$2,$o@H6 0.072700
change charge :$2,$o@H7 0.072700
change charge :$2,$o@H8 0.088200
change charge :$2,$o@H9 0.088200
change charge :$2,$o@N1 -0.488800
change charge :$2,$o@N2 0.108400
change charge :$2,$o@N3 -0.786500
change charge :$2,$o@N4 -0.680400
change charge :$2,$o@N5 -0.691400
change charge :$2,$o@N6 -0.505800
change charge :$2,$o@O1 -0.678800
change charge :$2,$o@O2 -0.678800
change charge :$2,$o@O3 -0.644500
change charge :$2,$o@S1 -0.140000
change charge :$2,$o@S2 1.444900
addLJType :$2@F4,F5,F6 radius 0 epsilon 0 radius_14 0 epsilon_14 0
addLJType :$2@C30 radius 1.4593 epsilon 0.0208 radius_14 1.4593 epsilon_14 0.0208

setBond	:$2@C27 :$2@C30 375.9000 1.0970

setAngle :$2@C30 :$2@C27 :$2@H32 39.0000 107.5800
setAngle :$2@C26 :$2@C27 :$2@C30 46.8000 109.8000
setAngle :$2@C28 :$2@C27 :$2@C30 46.8000 109.8000

deleteDihedral :$2@H30 :$2@C26 :$2@C27 :$2@C30
deleteDihedral :$2@H31 :$2@C26 :$2@C27 :$2@C30
deleteDihedral :$2@H33 :$2@C28 :$2@C27 :$2@C30
deleteDihedral :$2@H34 :$2@C28 :$2@C27 :$2@C30
deleteDihedral :$2@C25 :$2@C26 :$2@C27 :$2@C30
deleteDihedral :$2@C29 :$2@C28 :$2@C27 :$2@C30

addDihedral :$2@H30 :$2@C26 :$2@C27 :$2@C30 0.1200 3 0.0 1.2 2.0
addDihedral :$2@H31 :$2@C26 :$2@C27 :$2@C30 0.1200 3 0.0 1.2 2.0
addDihedral :$2@H33 :$2@C28 :$2@C27 :$2@C30 0.1200 3 0.0 1.2 2.0
addDihedral :$2@H34 :$2@C28 :$2@C27 :$2@C30 0.1200 3 0.0 1.2 2.0
addDihedral :$2@C25 :$2@C26 :$2@C27 :$2@C30 0.0800 3 0.0 1.2 2.0
addDihedral :$2@C29 :$2@C28 :$2@C27 :$2@C30 0.0800 3 0.0 1.2 2.0

setOverwrite
tiMerge :1-222 :223-444 :$o&!@H3,H4,H5,C5,S2,O1,O2,N3,C6,C7 :$2&!@H3,H4,H5,C5,S2,O1,O2,N3,C6,C7
outparm ${1}_merged.prm7 ${1}_merged.rst7
quit

EOF





