This is an example to conduct TI of ligand 004 to substructure A 
timask1 and timask2 may need to be changed depending on the ligand. Please see the Note in this readme.

Under the folder, complex is for complex state and monomer is for monomer state.
Under the complex and monomer folders, 1st is the first transition step and 2nd is the second transition step.

In 001.setup folder, initially you would only have leap.in, prmLA.sh, 004.lib, 004.frcmod and **_for_TI_tleap.pdb
Do the following steps to get merged prm7 and rst7
  1. tleap -f leap.in (leaprc.gaff2_modFClBrS is in input/tleap folder. The atom name in the pdb file may need to be changed, so they match the name in lib file.)     
  2. prmLA.sh 004 444 
  3. ambpdb -p 004_merged.prm7 <004_merged.rst7> tmp.pdb
  4. visualize tmp.pdb to check if every atoms are in the right place. Z-matrix of tleap may place missing atoms in odd positions. Adjust the misplaced atoms manually in MAESTRO and copy the coordinate of the adjusted atoms into **_for_TI_tleap.pdb. Redo step 1 to 3 and visualize to check again.
    
002.eq contains folders for each lambda windows and is for equilibration. Execute run.eq*.csh to conduct equilibration.

003.prod is for production runs. Copy the md6.rst7 files obtained from each lambda windows under 002.eq to the corresponding lambda windows under 003.prod for production runs.
Excute run.prod7.*.sh first.
Extend the prod7 run with run.prod[8-10].*.sh if necessary. The data in the paper are all from prod7. We didn't extend the runs. 

Sum up the free energy changes from each transition steps to obtain the overall free energy change of transition from ligand 004 to substructure A.

Note:
Amber18 GTI doesn't allow each timask to have more than 100 atoms. For ligands with more than 100 atoms, exclude some atoms from timerge and timask.
use the following mask for these transitions.
00400A timask1=':1 & !@H3,H4,H5,C5,S2,O1,O2,N3,C6,C7' , timask2=':2 & !@H3,H4,H5,C5,S2,O1,O2,N3,C6,C7'  (004 doesn't have more than 100 atoms but some atoms were excluded)
00900A timask1=':1 & !@H3,H4,H5,C5,S2,O1,O2,N3,C6,C7' , timask2=':2 & !@H3,H4,H5,C5,S2,O1,O2,N3,C6,C7'
05200A timask1=':1 & !@H3,H4,H5,C5,S2,O1,O2,N3,C6,C7' , timask2=':2 & !@H3,H4,H5,C5,S2,O1,O2,N3,C6,C7'
16500D timask1=':1 & !@C14,C22' , timask2=':2 & !@C14,C22'
18100C timask1=':1 & !@O1,O2,S2' , timask2=':2 & !@O1,O2,S2'
18500C timask1=':1 & !@C10,C14' , timask2=':2 & !@C10,C14' 
all other transitions timask1=':1' , timask2=':2' 