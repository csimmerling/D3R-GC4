This is an example to conduct TI of ligand 004 to substructure A

Under the folder, complex is for complex state and monomer is for monomer state.
Under the complex and monomer folders, 1st is the first transition step and 2nd is the second transition step.
The construction of transition steps is described under the "Transition from ligands to substructures and transitions between substructures" of main text
Under the 1st and 2nd folders, 001.setup contains the parameter and initial coordinate for ligand 004. The parameter file corresponds to the specific transition step.
002.eq contains folders for each lambda windows and is for equilibration.
003.prod is for production runs. Copy the md6.rst7 files obtained from each lambda windows under 002.eq to the corresponding lambda windows under 003.prod for production runs.
Sum up the free energy changes from each transition steps to obtain the overall free energy change of transition from ligand 004 to substructure A. 